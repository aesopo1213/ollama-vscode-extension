# Ollama for VS Code

Run Ollama language models locally from within VS Code.

## Features

- 🤖 Run Ollama models locally within VS Code
- 💬 Interactive chat interface
- 🔄 Stream responses in real-time
- 📋 Insert AI-generated code directly into your editor
- 🧠 Use context from your selected code
- 📚 Switch between different Ollama models
- 🔧 Configure API settings to your needs

## Requirements

- [Ollama](https://ollama.ai) installed and running on your system
- At least one model loaded in Ollama

## Getting Started

1. Install and run [Ollama](https://ollama.ai) on your system
2. Pull at least one model using the Ollama CLI (e.g., `ollama pull llama2`)
3. Install this extension in VS Code
4. Click on the Ollama icon in the activity bar or run "Ollama: Start New Chat" from the command palette

## Extension Commands

- **Ollama: Start New Chat**: Opens a new chat with Ollama
- **Ollama: Generate From Selection**: Generates content based on the selected text
- **Ollama: Refresh Available Models**: Refreshes the list of available models

## Configuration Options

- **API Base URL**: Configure the URL for the Ollama API (default: `http://localhost:11434`)
- **Default Model**: Set the default model for new chats
- **Show Streaming Output**: Enable/disable streaming model responses in real-time

## Privacy

All interactions with language models happen locally on your machine. No data is sent to external services.

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.